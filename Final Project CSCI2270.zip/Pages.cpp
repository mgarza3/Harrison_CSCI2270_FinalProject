#include "PageTurner.h"

Pages::Pages()
{
    //ctor
}

Pages::~Pages()
{
    //dtor
}
