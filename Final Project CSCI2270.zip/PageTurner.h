#ifndef PAGES_H
#define PAGES_H


class Pages
{
    public:
        Pages();
        virtual ~Pages();
    protected:
    private:
};

#endif // PAGES_H
