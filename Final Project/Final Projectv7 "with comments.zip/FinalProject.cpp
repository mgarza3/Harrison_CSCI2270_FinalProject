#include <iostream>
#include "PageTurner.h"

using namespace std;

int main()
{
    Pages P;//initialize class
    P.printMain(); //begin playing the game!
    return 0;
}
