#include <iostream>
#include "PageTurner.h"

using namespace std;

int main()
{
    Pages P;
    P.printMain();
    //cout << "Hello world!" << endl;
    return 0;
}
