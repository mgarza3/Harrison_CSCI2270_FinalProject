#include <iostream>
#include "PageTurner.h"

using namespace std;

int main()
{
    Pages classObj;
    classObj.printMain();
}
